APCL simulation extract

paired-results.csv: 1200 paired trials, no-recovery CPF and full recovery.
results.json: aggregate metrics, gate-conditioned subset and source SHA-256.
episode.npz: real q trajectories and weighted particle snapshots for seed 17.
episode.json: episode parameters, results and study source hashes.

Seed 17 is a selected development illustration, not aggregate evidence.
Its gate statistic is 0.3503 (accepted at c <= 0.87); it was selected to illustrate recovery.
Contact is an applied point force, fixed in the object frame, with a world-fixed nominal force.
Object geometry is visualized but is not supplied to the estimator.
Hardware experiments are pending. This is a research snapshot.

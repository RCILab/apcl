"""Parallel experiment runner. Each task = one trial seed: Phase 1 once, then every variant
branches from the same post-calibration state (paired comparison).

Usage: python run_experiments.py <experiment> [--seeds a:b] [--procs n]
Results: results/<experiment>.jsonl (one line per seed; resumable)."""
import argparse, json, os, sys, time, traceback
import numpy as np
from multiprocessing import Pool

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

OFF = dict(D1=False, D2=False, D3=False)
VARIANTS = {
    "none":        dict(cpf=OFF),
    "D1":          dict(cpf=dict(D1=True, D2=False, D3=False)),
    "D2":          dict(cpf=dict(D1=False, D2=True, D3=False)),
    "D3pa":        dict(cpf=dict(D1=False, D2=False, D3=True, D3_dir="pa")),
    "D3loa":       dict(cpf=dict(D1=False, D2=False, D3=True, D3_dir="loa")),
    "full":        dict(cpf=dict()),
    "none_random": dict(cpf=OFF, view="random"),
    "full_random": dict(cpf=dict(), view="random"),
    "full_maxrot": dict(cpf=dict(), view="maxrot"),
    "full_fimmean": dict(cpf=dict(), view="fim_mean"),
    "full_N500":   dict(cpf=dict(N=500)),
    "full_N1000":  dict(cpf=dict(N=1000)),
    "full_N5000":  dict(cpf=dict(N=5000)),
    "full_batch":  dict(cpf=dict(), batch=True, stop=False),
    "fullrandom_batch": dict(cpf=dict(), view="random", batch=True, stop=False),
    # hyper-parameter sensitivity (one parameter changed at a time)
    "full_eta10":  dict(cpf=dict(eta=0.10)),
    "full_eta50":  dict(cpf=dict(eta=0.50)),
    "full_lmin1":  dict(cpf=dict(ell_min=0.01)),
    "full_lmin10": dict(cpf=dict(ell_min=0.10)),
    "full_L5":     dict(cpf=dict(L=5)),
    "full_L20":    dict(cpf=dict(L=20)),
}
SWEEP_DEG = [0, 5, 10, 20, 30, 45]

EXPERIMENTS = {
    # development set (tuning only; never reported)
    "dev":    dict(seeds=(0, 200), variants=["none", "D3loa", "full", "none_random", "full_random"]),
    # main paired test set
    "main":   dict(seeds=(10000, 11200), variants=["none", "D1", "D2", "D3pa", "D3loa", "full",
                                                      "none_random", "full_random", "full_maxrot", "full_fimmean"]),
    "particles": dict(seeds=(10000, 10400), variants=["full_N500", "full_N1000", "full_N5000"]),
    "mass10":   dict(seeds=(20000, 20300), variants=["full"], mismatch="mass10"),
    "friction": dict(seeds=(21000, 21300), variants=["full"], mismatch="friction"),
    "sweep":    dict(seeds=(30000, 30300), sweep=True),
    # noise-limited sweep: no model/actuation errors, no follower variation, 5x torque noise
    "sweep_ideal": dict(seeds=(31000, 31300), sweep=True, ideal=True),
    "gate":     dict(seeds=(40000, 41000), variants=["full"], gate=True),
    "batch":    dict(seeds=(50000, 50400), variants=["full_batch", "fullrandom_batch"]),
    # uncertainty-budget mis-specification (budget keeps u_kappa = 1 %, eps_f = 3 %)
    "tau3":     dict(seeds=(23000, 23300), variants=["full"], mismatch="tau3"),
    "follower": dict(seeds=(24000, 24300), variants=["full"], follower=(0.05, 3.0)),
    "sens":     dict(seeds=(60000, 60300), variants=["full", "full_eta10", "full_eta50", "full_lmin1",
                                                      "full_lmin10", "full_L5", "full_L20"]),
}

_NOM = None


def _init():
    global _NOM
    from ctry.robot import Nominal
    _NOM = Nominal()


def _gate_mismatch(rng):
    """Mixed-severity model errors for the trust-gate study."""
    return dict(mass=rng.choice([0.02, 0.05, 0.10, 0.15]), com=rng.choice([0.002, 0.005, 0.01]),
                tau_scale=rng.choice([0.0, 0.03, 0.08]), fric=1.0, spring=rng.choice([0.0, 0.0, 1.0, 3.0]))


def _task(args):
    exp, seed = args
    from ctry.episode import sample_trial, phase1, phase2, validity_label
    import ctry.episode as ep
    cfg = EXPERIMENTS[exp]
    out = dict(seed=seed, exp=exp)
    try:
        mm = None
        if cfg.get("gate"):
            mm = _gate_mismatch(np.random.default_rng(seed + 555))
            out["mm"] = {k: float(v) for k, v in mm.items()}
        tr = sample_trial(seed, mismatch=cfg.get("mismatch", "nominal"), mm=mm)
        if cfg.get("follower"):
            tr["ripple"], tr["wobble_deg"] = cfg["follower"]
        if cfg.get("ideal"):
            tr["mass_scale"][:] = 1.0; tr["com_off"][:] = 0.0; tr["tau_scale"][:] = 0.0
            tr["friction"][:] = 0.0; tr["damping"][:] = 0.21; tr["ripple"] = 0.0; tr["wobble_deg"] = 0.0
            tr["tau_noise"] = 5.0 * tr["tau_noise"]
        t0 = time.time()
        plant, cal = phase1(tr, _NOM)
        out["phase1_wall"] = time.time() - t0
        out["c_stat"] = float(cal["c_stat"])
        out["theta"] = cal["theta"].tolist()
        out["m_true"] = float(tr["obj"]["mass"])
        if cfg.get("gate"):
            valid, rms = validity_label(tr, cal, _NOM)
            out["valid"], out["valid_rms"] = bool(valid), float(rms)
        out["res"] = {}
        if cfg.get("sweep"):
            # two views; second rotated about an axis perpendicular to the true force (in world)
            f = tr["fW"] / np.linalg.norm(tr["fW"])
            a = np.cross(f, np.random.default_rng(seed).standard_normal(3))
            a /= np.linalg.norm(a)
            for deg in SWEEP_DEG:
                if deg == 0:
                    var = dict(cpf=dict(), view="fixed", stop=False)
                    fv = [(a, 1e-9)]
                else:
                    var = dict(cpf=dict(), view="fixed", stop=False)
                    fv = [(a, np.deg2rad(deg))]
                saved = ep.MAX_VIEWS
                ep.MAX_VIEWS = 2
                try:
                    out["res"][f"deg{deg}"] = phase2(plant, cal, tr, var, _NOM, fixed_views=fv)
                finally:
                    ep.MAX_VIEWS = saved
        else:
            for v in cfg["variants"]:
                out["res"][v] = phase2(plant, cal, tr, VARIANTS[v], _NOM)
    except Exception:
        out["error"] = traceback.format_exc()
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("exp")
    ap.add_argument("--seeds", default=None)
    ap.add_argument("--procs", type=int, default=26)
    a = ap.parse_args()
    cfg = EXPERIMENTS[a.exp]
    lo, hi = cfg["seeds"] if a.seeds is None else map(int, a.seeds.split(":"))
    os.makedirs("results", exist_ok=True)
    path = f"results/{a.exp}.jsonl"
    done = set()
    if os.path.exists(path):
        with open(path) as fh:
            for line in fh:
                try:
                    d = json.loads(line)
                    if "error" not in d:
                        done.add(d["seed"])
                except json.JSONDecodeError:
                    pass
    todo = [(a.exp, s) for s in range(lo, hi) if s not in done]
    print(f"{a.exp}: {len(todo)} seeds to run ({len(done)} done)", flush=True)
    t0 = time.time()
    with Pool(a.procs, initializer=_init) as pool, open(path, "a") as fh:
        for i, out in enumerate(pool.imap_unordered(_task, todo)):
            fh.write(json.dumps(out, default=float) + "\n"); fh.flush()
            if "error" in out:
                print("ERROR seed", out["seed"], out["error"].splitlines()[-1], flush=True)
            if (i + 1) % 50 == 0:
                print(f"  {i+1}/{len(todo)}  {time.time()-t0:.0f}s", flush=True)
    print(f"done in {time.time()-t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()

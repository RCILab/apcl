"""Nominal-model kinematics/dynamics used by the estimator and the controller."""
import numpy as np
import mujoco
from .model import nominal_model, Q_LO, Q_HI, DAMPING


def skew(v):
    return np.array([[0, -v[2], v[1]], [v[2], 0, -v[0]], [-v[1], v[0], 0]])


def skew_batch(P):
    """(N,3) -> (N,3,3)"""
    Z = np.zeros(len(P))
    return np.stack([np.stack([Z, -P[:, 2], P[:, 1]], -1),
                     np.stack([P[:, 2], Z, -P[:, 0]], -1),
                     np.stack([-P[:, 1], P[:, 0], Z], -1)], 1)


def rotvec_to_R(w):
    th = np.linalg.norm(w)
    if th < 1e-12:
        return np.eye(3)
    k = w / th
    K = skew(k)
    return np.eye(3) + np.sin(th) * K + (1 - np.cos(th)) * K @ K


def R_to_rotvec(R):
    c = np.clip((np.trace(R) - 1) / 2, -1, 1)
    th = np.arccos(c)
    if th < 1e-9:
        return np.zeros(3)
    if np.pi - th < 1e-6:
        w, V = np.linalg.eigh((R + R.T) / 2)
        k = V[:, np.argmax(w)]
        return k * th
    return th / (2 * np.sin(th)) * np.array([R[2, 1] - R[1, 2], R[0, 2] - R[2, 0], R[1, 0] - R[0, 1]])


class Nominal:
    """Estimator-side model: known robot + hand, no payload."""

    def __init__(self):
        self.m = nominal_model()
        self.d = mujoco.MjData(self.m)
        self.sid = mujoco.mj_name2id(self.m, mujoco.mjtObj.mjOBJ_SITE, "tcp")
        self.nv = self.m.nv
        self._jp = np.zeros((3, self.nv))
        self._jr = np.zeros((3, self.nv))
        self._M = np.zeros((self.nv, self.nv))
        self.damping = DAMPING.copy()

    def set_state(self, q, qd=None):
        self.d.qpos[:] = q
        self.d.qvel[:] = 0 if qd is None else qd
        mujoco.mj_forward(self.m, self.d)

    def kin(self, q):
        """TCP rotation, position, and body Jacobian J_E (6x7: [lin; ang] in TCP frame)."""
        self.d.qpos[:] = q
        mujoco.mj_kinematics(self.m, self.d)
        mujoco.mj_comPos(self.m, self.d)
        R = self.d.site_xmat[self.sid].reshape(3, 3).copy()
        o = self.d.site_xpos[self.sid].copy()
        mujoco.mj_jacSite(self.m, self.d, self._jp, self._jr, self.sid)
        J = np.vstack([R.T @ self._jp, R.T @ self._jr])
        return R, o, J

    def dyn(self, q, qd):
        """Mass matrix and bias (C qd + g) of the nominal model."""
        self.set_state(q, qd)
        mujoco.mj_fullM(self.m, self.d, self._M)
        return self._M.copy(), self.d.qfrc_bias.copy()

    def gravity(self, q):
        self.set_state(q)
        return self.d.qfrc_bias.copy()

    def ik(self, q0, R_t, o_t, iters=200, q_rest=None, tol=1e-6):
        """Damped least-squares IK for the TCP pose with null-space pull toward q_rest."""
        q = q0.copy()
        q_rest = q0 if q_rest is None else q_rest
        mid = (Q_LO + Q_HI) / 2
        for _ in range(iters):
            R, o, J = self.kin(q)
            e_p = o_t - o
            e_r = R @ R_to_rotvec(R.T @ R_t)  # world-frame orientation error
            e = np.concatenate([e_p, e_r])
            if np.linalg.norm(e) < tol:
                break
            Jw = np.vstack([R @ J[:3], R @ J[3:]])
            lam = 1e-4
            JJt = Jw @ Jw.T + lam * np.eye(6)
            Jpinv = Jw.T @ np.linalg.solve(JJt, np.eye(6))
            N = np.eye(7) - Jpinv @ Jw
            dq = Jpinv @ e + N @ (0.1 * (q_rest - q) + 0.02 * (mid - q))
            q = np.clip(q + dq, Q_LO + 1e-3, Q_HI - 1e-3)
        R, o, _ = self.kin(q)
        err = np.linalg.norm(o_t - o) + np.linalg.norm(R_to_rotvec(R.T @ R_t))
        return q, err

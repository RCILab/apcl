"""Plant simulation: true FR3 + object, torque-controlled, with sensor/actuation errors,
a follower contact, and the generalized-momentum observer running on the nominal model."""
import numpy as np
import mujoco
from scipy.interpolate import CubicSpline
from .model import build_xml, TAU_MAX
from .robot import Nominal, rotvec_to_R, R_to_rotvec

KP = np.array([900, 900, 900, 900, 350, 250, 100.0])
KD = np.array([60, 60, 60, 60, 20, 15, 6.0])
K_OBS = 50.0          # observer gain [1/s]
SUB = 100             # samples per sub-window mean (0.1 s at 1 kHz)


def minjerk(x):
    x = np.clip(x, 0, 1)
    return 10 * x**3 - 15 * x**4 + 6 * x**5, (30 * x**2 - 60 * x**3 + 30 * x**4)


class Plant:
    def __init__(self, trial, rng, nominal=None):
        """trial: dict with keys obj, mass_scale, com_off, damping, friction, stiffness, springref,
        tau_scale, tau_noise, q_noise, qd_noise, q0."""
        self.trial = trial
        xml = build_xml(link_mass_scale=trial["mass_scale"], link_com_offset=trial["com_off"],
                        damping=trial["damping"], frictionloss=trial["friction"],
                        stiffness=trial["stiffness"], springref=trial["springref"], obj=trial["obj"])
        self.m = mujoco.MjModel.from_xml_string(xml)
        self.d = mujoco.MjData(self.m)
        self.dt = self.m.opt.timestep
        self.nom = nominal if nominal is not None else Nominal()
        self.rng = rng
        self.sid = mujoco.mj_name2id(self.m, mujoco.mjtObj.mjOBJ_SITE, "tcp")
        self.obj_bid = mujoco.mj_name2id(self.m, mujoco.mjtObj.mjOBJ_BODY, "object")
        self.d.qpos[:] = trial["q0"]
        mujoco.mj_forward(self.m, self.d)
        self.t = 0.0
        # trajectory
        self.traj = None
        self.q_hold = trial["q0"].copy()
        # observer
        self.I = np.zeros(7)
        self.r = np.zeros(7)
        self.M_prev = None
        self.p0 = None
        # contact
        self.contact = None
        self.wob = np.zeros(3)
        self.amp = 0.0
        # gravity pre-compensation of the payload in the controller (set after calibration)
        self.ff_theta = None
        self.last_tau = np.zeros(7)

    # ------------------------------------------------------------------ trajectories
    def set_hold(self, q):
        self.traj = None
        self.q_hold = q.copy()

    def move_through(self, waypoints, T):
        """Min-jerk time scaling along a cubic spline through joint waypoints (first = current target)."""
        W = np.asarray(waypoints)
        s = np.linspace(0, 1, len(W))
        self.traj = (self.t, T, CubicSpline(s, W, axis=0, bc_type="clamped"))

    def _desired(self):
        if self.traj is None:
            return self.q_hold, np.zeros(7), np.zeros(7)
        t0, T, cs = self.traj
        x = (self.t - t0) / T
        if x >= 1:
            self.q_hold = cs(1.0)
            self.traj = None
            return self.q_hold, np.zeros(7), np.zeros(7)
        s, sd = minjerk(x)
        sd = sd / T
        # second derivative of min-jerk
        sdd = (60 * x - 180 * x**2 + 120 * x**3) / T**2
        return cs(s), cs(s, 1) * sd, cs(s, 2) * sd**2 + cs(s, 1) * sdd

    # ------------------------------------------------------------------ contact
    def set_contact(self, p_E, f_W, ripple=0.02, wobble_deg=1.0, ramp=0.3):
        self.contact = dict(p=np.asarray(p_E, float), f=np.asarray(f_W, float), ripple=ripple,
                            wob=np.deg2rad(wobble_deg), t_on=self.t, ramp=ramp)

    def _contact_force(self):
        c = self.contact
        # slowly varying follower imperfection (OU processes, tau = 0.5 s)
        a = self.dt / 0.5
        self.wob += -a * self.wob + np.sqrt(2 * a) * c["wob"] * self.rng.standard_normal(3)
        self.amp += -a * self.amp + np.sqrt(2 * a) * c["ripple"] * self.rng.standard_normal()
        k = min(1.0, (self.t - c["t_on"]) / c["ramp"])
        return k * (1 + self.amp) * (rotvec_to_R(self.wob) @ c["f"])

    def true_tcp(self):
        return self.d.site_xmat[self.sid].reshape(3, 3).copy(), self.d.site_xpos[self.sid].copy()

    # ------------------------------------------------------------------ stepping
    def step(self):
        tr = self.trial
        q_true, qd_true = self.d.qpos.copy(), self.d.qvel.copy()
        qm = q_true + tr["q_noise"] * self.rng.standard_normal(7)
        qdm = qd_true + tr["qd_noise"] * self.rng.standard_normal(7)
        M, bias = self.nom.dyn(qm, qdm)
        qd_, qdd_, qddd_ = self._desired()
        tau = bias + self.nom.damping * qdm + M @ qddd_ + KP * (qd_ - qm) + KD * (qdd_ - qdm)
        if self.ff_theta is not None:
            tau -= self.ff_Y(qm) @ self.ff_theta
        tau = np.clip(tau, -0.95 * TAU_MAX, 0.95 * TAU_MAX)
        applied = (1 + tr["tau_scale"]) * tau + tr["tau_noise"] * self.rng.standard_normal(7)
        self.d.ctrl[:] = applied
        self.d.xfrc_applied[:] = 0
        if self.contact is not None:
            f = self._contact_force()
            R, o = self.true_tcp()
            pw = o + R @ self.contact["p"]
            self.d.xfrc_applied[self.obj_bid, :3] = f
            self.d.xfrc_applied[self.obj_bid, 3:] = np.cross(pw - self.d.xipos[self.obj_bid], f)
        mujoco.mj_step(self.m, self.d)
        self.t += self.dt
        # momentum observer (nominal model, measured signals)
        p = M @ qdm
        if self.M_prev is None:
            self.M_prev = M
            self.p0 = p.copy()
        Mdot_qd = (M - self.M_prev) @ qdm / self.dt
        self.M_prev = M
        self.I += (tau - bias - self.nom.damping * qdm + Mdot_qd + self.r) * self.dt
        self.r = K_OBS * (p - self.I - self.p0)
        self.last_tau = tau
        return qm, tau

    def run(self, duration, record=False):
        """Advance; if record, return sub-window means of residual and measured q."""
        n = int(round(duration / self.dt))
        if not record:
            for _ in range(n):
                self.step()
            return None
        R_list, Q_list = [], []
        acc_r, acc_q, c = np.zeros(7), np.zeros(7), 0
        for _ in range(n):
            qm, _ = self.step()
            acc_r += self.r
            acc_q += qm
            c += 1
            if c == SUB:
                R_list.append(acc_r / SUB)
                Q_list.append(acc_q / SUB)
                acc_r[:], acc_q[:], c = 0, 0, 0
        return np.array(R_list), np.array(Q_list)

    def ff_Y(self, q):
        from .estimator import payload_regressor
        R, _, J = self.nom.kin(q)
        return payload_regressor(R, J)

"""Estimator: payload calibration, trust gate, force-profiled CPF with D1/D2/D3 recovery,
and profile-Fisher-information next-view scoring. Uses only the nominal model."""
import numpy as np
from scipy.stats import chi2
from .robot import skew, skew_batch

G_W = np.array([0.0, 0.0, -9.81])


# ====================================================================== Phase 1
def payload_regressor(R, J):
    """Y (7x4) with residual = Y @ [m, m c] for a payload rigidly attached to the TCP frame."""
    gE = R.T @ G_W
    W = np.zeros((6, 4))
    W[:3, 0] = gE
    W[3:, 1:] = -skew(gE)
    return J.T @ W


def calibrate(Ys, rs, lam=1e-4):
    """Ridge LS for theta plus leave-one-out per-joint residual RMS (model-error scale)."""
    Ys, rs = np.asarray(Ys), np.asarray(rs)
    def fit(idx):
        A = np.concatenate(Ys[idx]); b = np.concatenate(rs[idx])
        return np.linalg.solve(A.T @ A + lam * np.eye(4), A.T @ b)
    n = len(Ys)
    theta = fit(np.arange(n))
    loo = np.array([rs[j] - Ys[j] @ fit(np.delete(np.arange(n), j)) for j in range(n)])
    return theta, np.sqrt(np.mean(loo**2, axis=0))


def gate_statistic(Ys_c, rs_c, theta, sigma_g):
    return max(float(np.mean(((r - Y @ theta) / sigma_g) ** 2)) for Y, r in zip(Ys_c, rs_c))


# ====================================================================== profile likelihood
def B_batch(P):
    N = len(P)
    B = np.zeros((N, 6, 3))
    B[:, :3, :] = np.eye(3)
    B[:, 3:, :] = skew_batch(P)
    return B


# Type-B components of the residual uncertainty budget (GUM): residual dry friction after
# compensation, uniform with half-width A_FRIC -> A/sqrt(3); torque-constant tolerance U_SCALE
# (relative, applied to the load-dependent part of the residual).
A_FRIC = np.array([0.06] * 4 + [0.03] * 3)
U_SCALE = 0.01


def residual_var(rbar, n, sig_sub2, sig_mod2):
    return sig_sub2 / n + sig_mod2 + A_FRIC**2 / 3 + (U_SCALE * rbar) ** 2


class View:
    def __init__(self, R, J, sig_sub2, sig_mod2):
        self.R, self.A = R, J.T
        self.sig_sub2, self.sig_mod2 = sig_sub2, sig_mod2
        self.rsum = np.zeros(7)
        self.n = 0

    def var(self, rbar):
        return residual_var(rbar, self.n, self.sig_sub2, self.sig_mod2)

    def stats(self):
        rbar = self.rsum / self.n
        W = np.diag(1.0 / self.var(rbar))
        return self.A.T @ W @ self.A, self.A.T @ W @ rbar, rbar @ W @ rbar, W


def profile(P, stats_list, sig_df=0.0):
    """S(p) (= -2 log profile likelihood + const) and f_hat(p) (world) for particles P (N,3).

    stats_list: per-view (Q, b, c, R). With sig_df > 0, each view's force is f + delta_k,
    delta_k ~ N(0, sig_df^2 I) (follower-force variation), marginalized in closed form:
    Woodbury for the weight matrix and the determinant lemma for the normalizer."""
    B = B_batch(P)
    N = len(P)
    H = np.zeros((N, 3, 3)); g = np.zeros((N, 3)); c_tot = np.zeros(N); ld = np.zeros(N)
    I3 = np.eye(3)
    for Q, b, c, R in stats_list:
        T = np.einsum("nia,ij,njb->nab", B, Q, B)           # B^T Q B
        u = np.einsum("nia,i->na", B, b)                     # B^T b
        if sig_df > 0:
            K = np.linalg.inv(I3 / sig_df**2 + T)            # (s I + T)^-1
            TK = T @ K
            T_eff = T - TK @ T
            u_eff = u - np.einsum("nab,nb->na", TK, u)
            c_eff = c - np.einsum("na,nab,nb->n", u, K, u)
            ld += np.linalg.slogdet(I3 + sig_df**2 * T)[1]
        else:
            T_eff, u_eff, c_eff = T, u, c
        H += np.einsum("ab,nbc,dc->nad", R, T_eff, R)
        g += np.einsum("ab,nb->na", R, u_eff)
        c_tot += c_eff
    H += 1e-9 * I3
    f = np.linalg.solve(H, g[..., None])[..., 0]
    S = c_tot - np.einsum("na,na->n", g, f) + ld
    return S, f


def profile_info(P, F, views_W, sig_df=0.0):
    """Profile (Schur) information on p for each (p_i, f_i); views_W = list of (A, R, W).
    With sig_df > 0 the per-view weight includes the follower-force variation (Woodbury)."""
    N = len(P)
    I = np.zeros((N, 6, 6))
    B = B_batch(P)
    I3 = np.eye(3)
    for A, R, W in views_W:
        fk = F @ R  # rows: R^T f
        Hf = np.zeros((N, 6, 3)); Hf[:, 3:, :] = -skew_batch(fk)
        Hp = np.einsum("ij,njk->nik", A, Hf)                        # d r / d p
        Hff = np.einsum("ij,njk,lk->nil", A, B, R)                   # d r / d f
        H = np.concatenate([Hp, Hff], axis=2)                        # (N,7,6)
        I += np.einsum("nia,ij,njb->nab", H, W, H)
        if sig_df > 0:
            AB = np.einsum("ij,njk->nik", A, B)                      # (N,7,3)
            T = np.einsum("nia,ij,njb->nab", AB, W, AB)
            K = np.linalg.inv(I3 / sig_df**2 + T)
            X = np.einsum("nia,ij,njb->nab", H, W, AB)               # (N,6,3)
            I -= X @ K @ np.swapaxes(X, 1, 2)
    Ipp, Ipf, Iff = I[:, :3, :3], I[:, :3, 3:], I[:, 3:, 3:]
    return Ipp - Ipf @ np.linalg.solve(Iff + 1e-9 * np.eye(3), np.swapaxes(Ipf, 1, 2))


# ====================================================================== CPF
DEFAULT = dict(N=3000, rho_th=0.02, eta=0.30, r_nar=0.05, L=10, kappa=3.0, ell_min=0.03,
               sigma0=0.005, anneal=0.9, sigma_min=0.0005, ess_resample=0.5,
               cooldown=5, cap_pose=2, cap_run=8,
               D1=True, D2=True, D3=True, D3_dir="loa", eps_f=0.03)


class CPF:
    def __init__(self, lo, hi, rng, **cfg):
        self.c = dict(DEFAULT); self.c.update(cfg)
        self.lo, self.hi = np.asarray(lo), np.asarray(hi)
        self.rng = rng
        N = self.c["N"]
        self.P = rng.uniform(self.lo, self.hi, size=(N, 3))
        self.logw = np.zeros(N)
        self.views = []
        self.u = 0
        self.d2_count = 0
        self.cool = 0
        self.act_pose = 0
        self.act_run = 0
        self.counts = dict(D1=0, D2=0, D3=0, resample=0)
        self.S = np.zeros(N)
        self.fmag = 0.0

    # -------------------------------------------------------------- helpers
    def w(self):
        lw = self.logw - self.logw.max()
        w = np.exp(lw)
        return w / w.sum()

    def ess(self):
        w = self.w()
        return 1.0 / np.sum(w**2)

    def moments(self):
        w = self.w()
        m = w @ self.P
        D = self.P - m
        C = (D * w[:, None]).T @ D
        d = np.linalg.norm(D, axis=1)
        o = np.argsort(d)
        r95 = d[o][np.searchsorted(np.cumsum(w[o]), 0.95)]
        return m, C, r95

    def stats_list(self):
        out = []
        for v in self.views:
            if v.n > 0:
                Q, b, c, _ = v.stats()
                out.append((Q, b, c, v.R))
        return out

    def sig_df(self):
        return self.c["eps_f"] * self.fmag

    def profile(self, P=None):
        P = self.P if P is None else P
        sl = self.stats_list()
        if not sl:
            return np.zeros(len(P)), np.zeros((len(P), 3))
        return profile(P, sl, self.sig_df())

    def force_hat(self):
        m, _, _ = self.moments()
        return self.profile(m[None])[1][0]

    def _systematic(self):
        N = len(self.P)
        w = self.w()
        u = (self.rng.random() + np.arange(N)) / N
        idx = np.minimum(np.searchsorted(np.cumsum(w), u), N - 1)
        self.P = self.P[idx]
        self.S = self.S[idx]
        self.logw = np.zeros(N)
        self.counts["resample"] += 1

    def _clip(self, P):
        return np.clip(P, self.lo, self.hi)

    def _reweight_full(self):
        S, _ = self.profile()
        self.S = S
        self.logw = -0.5 * (S - S.min())

    def _chord(self, p, u, n):
        """n uniform samples on the chord of the box through p along u."""
        with np.errstate(divide="ignore", invalid="ignore"):
            t1 = (self.lo - p) / u; t2 = (self.hi - p) / u
        tmin = np.nanmax(np.where(np.abs(u) > 1e-12, np.minimum(t1, t2), -np.inf))
        tmax = np.nanmin(np.where(np.abs(u) > 1e-12, np.maximum(t1, t2), np.inf))
        return p + self.rng.uniform(tmin, tmax, n)[:, None] * u

    def _guard_ok(self):
        return self.cool == 0 and self.act_pose < self.c["cap_pose"] and self.act_run < self.c["cap_run"]

    def _mark(self, rule):
        self.counts[rule] += 1
        self.cool = self.c["cooldown"]
        self.act_pose += 1
        self.act_run += 1

    # -------------------------------------------------------------- view API
    def start_view(self, R, J, sig_sub2, sig_mod2):
        self.views.append(View(R, J, sig_sub2, sig_mod2))
        self.act_pose = 0

    def update(self, r_sub):
        c = self.c
        N = len(self.P)
        # 1. roughening with annealed width
        sig = max(c["sigma_min"], c["sigma0"] * c["anneal"] ** self.u)
        self.P = self._clip(self.P + sig * self.rng.standard_normal(self.P.shape))
        # 2. profile before / after the new sample at the current particle positions
        S_old, _ = self.profile()
        v = self.views[-1]
        v.rsum += r_sub; v.n += 1
        S_new, _ = self.profile()
        # 3. weights and diagnostics
        self.logw += -0.5 * (S_new - S_old)
        self.S = S_new
        self.u += 1
        if self.cool > 0:
            self.cool -= 1
        ess = self.ess()
        m, C, r95 = self.moments()
        dof = max(1, 7 * len(self.views) - 6)
        inconsistent = S_new.min() > chi2.ppf(0.99, dof)
        self.d2_count = self.d2_count + 1 if (r95 < c["r_nar"] and inconsistent) else 0
        # 4-5. recovery / resampling
        if c["D2"] and self.d2_count >= c["L"] and self._guard_ok():
            self._inject_D2(m)
            self._mark("D2")
            self.d2_count = 0
        elif c["D1"] and ess / N < c["rho_th"] and self._guard_ok():
            self._systematic()
            k = int(c["eta"] * N)
            idx = self.rng.choice(N, k, replace=False)
            js = max(3 * sig, 0.002)
            self.P[idx] = self._clip(self.P[idx] + js * self.rng.standard_normal((k, 3)))
            self._mark("D1")
        elif ess / N < c["ess_resample"]:
            self._systematic()
        self.fmag = float(np.linalg.norm(self.force_hat()))
        return dict(ess=ess, r95=r95)

    def _inject_D2(self, m):
        N = len(self.P)
        self._systematic()
        k = int(self.c["eta"] * N)
        idx = self.rng.choice(N, k, replace=False)
        k1, k2 = k // 3, k // 3
        k3 = k - k1 - k2
        f = self.force_hat()
        u = self.views[-1].R.T @ f
        u = u / (np.linalg.norm(u) + 1e-12)
        line = self._chord(m, u, k1)
        local = self.P[self.rng.choice(N, k2)] + 0.01 * self.rng.standard_normal((k2, 3))
        cand = self.rng.uniform(self.lo, self.hi, size=(10 * k3, 3))
        Sc, _ = self.profile(cand)
        wc = np.exp(-0.5 * (Sc - Sc.min())); wc /= wc.sum()
        glob = cand[self.rng.choice(len(cand), k3, p=wc)]
        self.P[idx] = self._clip(np.vstack([line, local, glob]))
        self._reweight_full()

    def end_view(self, info_std_along=None):
        """D3 at the end of a pose. info_std_along: CRB std along the line of action (theory trigger)."""
        c = self.c
        if not c["D3"] or self.act_run >= c["cap_run"]:
            return False
        m, C, _ = self.moments()
        lam, V = np.linalg.eigh(C)
        lam, V = lam[::-1], V[:, ::-1]
        if c["D3_dir"] == "loa":
            f = self.force_hat()
            u = self.views[-1].R.T @ f
            u = u / (np.linalg.norm(u) + 1e-12)
            fire = info_std_along is not None and info_std_along >= c["ell_min"]
        else:
            u = V[:, 0]
            fire = lam[0] >= c["kappa"] * lam[1] and np.sqrt(lam[0]) >= c["ell_min"]
        if not fire:
            return False
        N = len(self.P)
        self._systematic()
        k = int(c["eta"] * N)
        idx = self.rng.choice(N, k, replace=False)
        # perpendicular spread = current posterior spread orthogonal to u
        Pu = np.eye(3) - np.outer(u, u)
        sp = np.sqrt(max(np.trace(Pu @ C @ Pu) / 2, 1e-8))
        nu = (sp * self.rng.standard_normal((k, 3))) @ Pu
        self.P[idx] = self._clip(self._chord(m, u, k) + nu)
        self._reweight_full()
        self._mark("D3")
        return True

    # -------------------------------------------------------------- output
    def summary(self):
        m, C, r95 = self.moments()
        f = self.profile(m[None])[1][0]
        return m, C, r95, f


# ====================================================================== batch baseline
def batch_estimate(stats_list, views_W, sig_df, lo, hi, rng, n_grid=20000, n_start=10):
    """Non-recursive baseline on the same windows: global grid search of the profile objective S(p)
    over B and multi-start Nelder-Mead refinement (maximum marginal likelihood), with a rank-aware
    Gaussian covariance from the analytic profile Fisher information of the data at the estimate
    (directions without information are capped at the size of B). The analytic information is used
    instead of a numerical Hessian because the follower-variation normalizer adds a weak curvature
    along the line of action that a numerical Hessian would misread as data information."""
    from scipy.optimize import minimize
    lo, hi = np.asarray(lo), np.asarray(hi)
    G = rng.uniform(lo, hi, size=(n_grid, 3))
    S = np.concatenate([profile(G[i:i + 5000], stats_list, sig_df)[0] for i in range(0, n_grid, 5000)])
    fun = lambda x: float(profile(np.clip(x, lo, hi)[None], stats_list, sig_df)[0][0])
    best = None
    for x0 in G[np.argsort(S)[:n_start]]:
        r = minimize(fun, x0, method="Nelder-Mead", options=dict(xatol=1e-5, fatol=1e-4, maxiter=600))
        if best is None or r.fun < best.fun:
            best = r
    p = np.clip(best.x, lo, hi)
    f = profile(p[None], stats_list, sig_df)[1]
    Info = profile_info(p[None], f, views_W, sig_df)[0]
    w, V = np.linalg.eigh(0.5 * (Info + Info.T))
    var_cap = float(np.sum((hi - lo) ** 2))
    var = np.where(w > 1.0 / var_cap, 1.0 / np.maximum(w, 1e-30), var_cap)
    C = (V * var) @ V.T
    Z = rng.multivariate_normal(p, C, size=4000, check_valid="ignore")
    r95 = float(np.percentile(np.linalg.norm(Z - p, axis=1), 95))
    return p, C, r95

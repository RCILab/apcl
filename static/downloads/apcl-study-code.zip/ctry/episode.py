"""One localization episode: Phase 1 (settle, compact calibration, challenge, return) and
Phase 2 (contact, windows, CPF + recovery, next-view selection, position-preserving motion).
Phase 1 runs once per trial; every Phase-2 variant branches from the same saved state."""
import copy
import time
import numpy as np
from scipy.stats import chi2
from .model import box_object, Q_READY, Q_LO, Q_HI, TAU_MAX
from .robot import Nominal, rotvec_to_R, R_to_rotvec
from .sim import Plant, SUB
from .estimator import payload_regressor, calibrate, gate_statistic, CPF, profile_info

# search region B in the TCP frame [m]
B_LO = np.array([-0.15, -0.15, -0.05])
B_HI = np.array([0.15, 0.15, 0.30])
SIGMA_GATE = 0.1          # fixed absolute residual scale for the trust statistic [N m]
T_MOVE_CAL, T_SET_CAL, T_WIN_CAL = 1.5, 0.5, 1.0
T_MOVE, T_SET, T_WIN = 2.0, 1.0, 1.5
MAX_VIEWS = 5
MIN_VIEWS = 2
R95_STOP = 0.010
R_CONF, E_TOL = 0.010, 0.020


# ====================================================================== trial sampling
def _cone_dir(axis, half_angle, rng):
    cos_t = rng.uniform(np.cos(half_angle), 1.0)
    phi = rng.uniform(0, 2 * np.pi)
    a = axis / np.linalg.norm(axis)
    t = np.cross(a, [1, 0, 0]) if abs(a[0]) < 0.9 else np.cross(a, [0, 1, 0])
    t /= np.linalg.norm(t)
    b = np.cross(a, t)
    s = np.sqrt(1 - cos_t**2)
    return cos_t * a + s * (np.cos(phi) * t + np.sin(phi) * b)


def _surface_point(obj, rng):
    """Uniform point on the box surface except the face attached to the hand (z = offset_z)."""
    lx, ly, lz = obj["dims"]; ox, oy, oz = obj["offset"]
    faces = [("+x", ly * lz), ("-x", ly * lz), ("+y", lx * lz), ("-y", lx * lz), ("+z", lx * ly)]
    a = np.array([f[1] for f in faces]); k = rng.choice(5, p=a / a.sum())
    u, v = rng.random(2)
    x, y, z = ox + (u - 0.5) * lx, oy + (v - 0.5) * ly, oz + rng.random() * lz
    name = faces[k][0]
    if name == "+x": x, n = ox + lx / 2, np.array([1, 0, 0.])
    elif name == "-x": x, n = ox - lx / 2, np.array([-1, 0, 0.])
    elif name == "+y": y, n = oy + ly / 2, np.array([0, 1, 0.])
    elif name == "-y": y, n = oy - ly / 2, np.array([0, -1, 0.])
    else:
        x, y, z = ox + (u - 0.5) * lx, oy + (v - 0.5) * ly, oz + lz
        n = np.array([0, 0, 1.])
    return np.array([x, y, z]), n


MISMATCH = {
    "nominal": dict(mass=0.03, com=0.003, tau_scale=0.01, fric=1.0, spring=0.0),
    "mass10": dict(mass=0.10, com=0.005, tau_scale=0.01, fric=1.0, spring=0.0),
    "friction": dict(mass=0.03, com=0.003, tau_scale=0.01, fric=3.0, spring=0.0),
    "tau3": dict(mass=0.03, com=0.003, tau_scale=0.03, fric=1.0, spring=0.0),
}


def sample_trial(seed, mismatch="nominal", force_range=(5.0, 25.0), payload_range=(0.3, 1.5), mm=None):
    rng = np.random.default_rng(seed)
    nom = Nominal()
    mm = MISMATCH[mismatch] if mm is None else mm
    for _ in range(100):
        q0 = Q_READY + rng.uniform(-1, 1, 7) * np.array([0.25, 0.15, 0.25, 0.15, 0.25, 0.15, 0.25])
        q0 = np.clip(q0, Q_LO + 0.2, Q_HI - 0.2)
        dims = (rng.uniform(0.04, 0.10), rng.uniform(0.04, 0.10), rng.uniform(0.10, 0.22))
        off = (rng.uniform(-0.03, 0.03), rng.uniform(-0.03, 0.03), 0.0)
        obj = box_object(dims, off, rng.uniform(*payload_range))
        p, n = _surface_point(obj, rng)
        R0, _, J0 = nom.kin(q0)
        fE = rng.uniform(*force_range) * _cone_dir(-n, np.deg2rad(60), rng)
        fW = R0 @ fE
        # static feasibility at home and at 30 deg tilts: contact + payload + nominal gravity
        ok = True
        for ax in [None, (1, 0, 0), (0, 1, 0), (-1, 0, 0), (0, -1, 0)]:
            if ax is None:
                q = q0
            else:
                Rt = rotvec_to_R(np.deg2rad(30) * np.array(ax, float)) @ R0
                q, err = nom.ik(q0, Rt, nom.kin(q0)[1])
                if err > 1e-3:
                    continue
            R, _, J = nom.kin(q)
            f_E = R.T @ fW
            tau = nom.gravity(q) + J.T @ np.concatenate([f_E, np.cross(p, f_E)]) \
                + payload_regressor(R, J) @ np.concatenate([[obj["mass"]], obj["mass"] * obj["com"]])
            if np.any(np.abs(tau) > 0.8 * TAU_MAX):
                ok = False
                break
        if ok:
            break
    trial = dict(
        seed=seed, obj=obj, p=p, n=n, fW=fW, q0=q0,
        mass_scale=np.clip(1 + mm["mass"] * rng.standard_normal(7), 1 - 2.5 * mm["mass"], 1 + 2.5 * mm["mass"]),
        com_off=mm["com"] * rng.standard_normal((7, 3)),
        damping=0.21 * (1 + rng.uniform(-0.2, 0.2, 7)),
        friction=mm["fric"] * np.concatenate([rng.uniform(0.02, 0.06, 4), rng.uniform(0.01, 0.03, 3)]),
        stiffness=mm["spring"] * np.array([0, 1, 0, 1, 0, 0, 0.]), springref=q0.copy(),
        tau_scale=mm["tau_scale"] * rng.standard_normal(7),
        tau_noise=np.array([0.2] * 4 + [0.05] * 3), q_noise=np.full(7, 2e-5), qd_noise=np.full(7, 2e-3),
        ripple=0.02, wobble_deg=1.0,
    )
    return trial


# ====================================================================== motion helpers
def orient_waypoints(nom, q_from, R_to, o_fix, n=8):
    R_from, _, _ = nom.kin(q_from)
    w = R_to_rotvec(R_to @ R_from.T)
    qs, q = [q_from.copy()], q_from.copy()
    for s in np.linspace(0, 1, n)[1:]:
        q, err = nom.ik(q, rotvec_to_R(s * w) @ R_from, o_fix, q_rest=q_from)
        if err > 2e-3:
            return None
        qs.append(q)
    return qs


def move_and_settle(plant, qs, T_move, T_settle, extra_tau=None):
    plant.move_through(qs, T_move)
    plant.run(T_move)
    plant.set_hold(qs[-1])
    plant.run(T_settle)


def window(plant, T):
    Rs, Qs = plant.run(T, record=True)
    return Rs, Qs


# ====================================================================== Phase 1
CAL_AXES = [(1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (1, 1, 0), (-1, -1, 0)]
CAL_ANGLE = np.deg2rad(20)
CH_AXES = [(1, -1, 0), (-1, 1, 0), (0.5, 1, 0)]
CH_ANGLE = np.deg2rad(35)


def phase1(trial, nom=None):
    nom = nom or Nominal()
    rng = np.random.default_rng(trial["seed"] + 7919)
    plant = Plant(trial, rng, nominal=nom)
    plant.run(1.0)
    q_home = trial["q0"].copy()
    R_home, o_home, _ = nom.kin(q_home)

    def visit(ax, ang, T_win):
        Rt = rotvec_to_R(ang * np.array(ax, float) / np.linalg.norm(ax)) @ R_home
        qs = orient_waypoints(nom, plant.q_hold, Rt, o_home)
        if qs is None:
            return None
        move_and_settle(plant, qs, T_MOVE_CAL, T_SET_CAL)
        return window(plant, T_win)

    Ys, rs, sub_var = [], [], []
    def add(win, Ylist, rlist):
        Rw, Qw = win
        R, _, J = nom.kin(Qw.mean(0))
        Ylist.append(payload_regressor(R, J)); rlist.append(Rw.mean(0))
        sub_var.append(Rw.var(0, ddof=1))

    add(window(plant, T_WIN_CAL), Ys, rs)
    for ax in CAL_AXES:
        w = visit(ax, CAL_ANGLE, T_WIN_CAL)
        if w is not None:
            add(w, Ys, rs)
    theta, sig_loo = calibrate(Ys, rs)
    Yc, rc = [], []
    for ax in CH_AXES:
        w = visit(ax, CH_ANGLE, T_WIN_CAL)
        if w is not None:
            add(w, Yc, rc)
    c_stat = gate_statistic(Yc, rc, theta, SIGMA_GATE) if Yc else np.inf
    # return home along a real trajectory
    qs = orient_waypoints(nom, plant.q_hold, R_home, o_home)
    move_and_settle(plant, qs, T_MOVE_CAL, 1.0)
    sig_ch = np.sqrt(np.mean([(r - Y @ theta) ** 2 for Y, r in zip(Yc, rc)], axis=0)) if Yc else sig_loo
    cal = dict(theta=theta, sig_mod2=np.maximum(np.maximum(sig_loo, sig_ch), 0.01) ** 2, sig_loo=sig_loo, sig_ch=sig_ch,
               sig_sub2=np.maximum(np.mean(sub_var, 0), 1e-8), c_stat=c_stat, n_cal=len(Ys), n_ch=len(Yc),
               q_home=plant.q_hold.copy(), R_home=R_home, o_home=o_home)
    return plant, cal


def validity_label(trial, cal, nom=None, n_test=40, thr=0.25):
    """Ground truth: RMS static compensation error over random test orientations (<= 35 deg)."""
    nom = nom or Nominal()
    rng = np.random.default_rng(trial["seed"] + 104729)
    pl = Plant(trial, rng, nominal=nom)
    import mujoco
    errs = []
    q = cal["q_home"]
    for _ in range(n_test):
        ax = rng.standard_normal(3); ax[2] *= 0.3
        Rt = rotvec_to_R(np.deg2rad(rng.uniform(0, 35)) * ax / np.linalg.norm(ax)) @ cal["R_home"]
        qt, err = nom.ik(q, Rt, cal["o_home"])
        if err > 1e-3:
            continue
        pl.d.qpos[:] = qt; pl.d.qvel[:] = 0
        mujoco.mj_forward(pl.m, pl.d)
        # static commanded torque the controller needs, divided by actuator scale; spring included
        tau_true = (pl.d.qfrc_bias - pl.d.qfrc_passive) / (1 + trial["tau_scale"])
        R, _, J = nom.kin(qt)
        r_true = nom.gravity(qt) - tau_true            # what the observer sees at rest (no contact)
        errs.append(np.linalg.norm(r_true - payload_regressor(R, J) @ cal["theta"]) ** 2)
    rms = np.sqrt(np.mean(errs)) if errs else np.inf
    return rms <= thr, rms


# ====================================================================== Phase 2
def candidates(nom, q_cur, R_cur, R_home, o_fix, visited, angles_deg=(10, 20, 30), min_sep_deg=5.0):
    """Orientations within the validated envelope: rotations of the HOME orientation by
    angles_deg about 26 axes. Candidates within min_sep_deg of a visited view are dropped.
    `ang` is the rotation needed from the current orientation (motion cost)."""
    axes = [np.array(a, float) - 1 for a in np.ndindex(3, 3, 3) if np.any(np.array(a) != 1)]
    out = []
    for ang in angles_deg:
        for a in axes:
            a = a / np.linalg.norm(a)
            Rt = rotvec_to_R(np.deg2rad(ang) * a) @ R_home
            if any(np.linalg.norm(R_to_rotvec(Rv.T @ Rt)) < np.deg2rad(min_sep_deg) for Rv in visited):
                continue
            q, err = nom.ik(q_cur, Rt, o_fix, iters=100, q_rest=q_cur)
            if err > 2e-3:
                continue
            out.append(dict(q=q, R=Rt, ang=float(np.linalg.norm(R_to_rotvec(R_cur.T @ Rt))), axis=a, tilt=ang))
    return out


def feasible(nom, cand, theta, f_hat_W, p_hat):
    R, _, J = nom.kin(cand["q"])
    fE = R.T @ f_hat_W
    tau = nom.gravity(cand["q"]) + payload_regressor(R, J) @ theta + J.T @ np.concatenate([fE, np.cross(p_hat, fE)])
    lim_ok = np.all(cand["q"] > Q_LO + 0.05) and np.all(cand["q"] < Q_HI - 0.05)
    return lim_ok and np.all(np.abs(tau) < 0.85 * TAU_MAX)


def score_candidates(nom, cpf, cands, cal, mode, rng, M=64, lam_m=1.0, eps=1.0):
    from .estimator import residual_var
    rlast = cpf.views[-1].rsum / cpf.views[-1].n
    W_c = np.diag(1.0 / residual_var(rlast, T_WIN / 0.1, cal["sig_sub2"], cal["sig_mod2"]))
    past = []
    for v in cpf.views:
        _, _, _, W = v.stats()
        past.append((v.A, v.R, W))
    w = cpf.w()
    if mode == "fim_mean":
        m, _, _ = cpf.moments()
        P = m[None]; wb = np.ones(1)
    else:
        N = len(w)
        u = (rng.random() + np.arange(M)) / M
        idx = np.minimum(np.searchsorted(np.cumsum(w), u), N - 1)
        P = cpf.P[idx]; wb = np.full(M, 1.0 / M)
    _, F = cpf.profile(P)
    scores = []
    for cd in cands:
        _, _, J = nom.kin(cd["q"])
        I = profile_info(P, F, past + [(J.T, cd["R"], W_c)], cpf.sig_df())
        sign, ld = np.linalg.slogdet(I + eps * np.eye(3))
        scores.append(float(wb @ ld) - lam_m * cd["ang"])
    return np.array(scores)


def along_line_std(cpf, cal):
    """CRB std of p along the current line of action, from the views collected so far."""
    m, _, _ = cpf.moments()
    f = cpf.force_hat()
    past = [(v.A, v.R, v.stats()[3]) for v in cpf.views]
    I = profile_info(m[None], f[None], past, cpf.sig_df())[0]
    u = cpf.views[-1].R.T @ f
    u /= np.linalg.norm(u) + 1e-12
    try:
        return float(np.sqrt(max(u @ np.linalg.solve(I + 1e-6 * np.eye(3), u), 0)))
    except np.linalg.LinAlgError:
        return np.inf


def phase2(plant, cal, trial, variant, nom=None, fixed_views=None, seed_offset=0, snapshots=None):
    """variant: dict(cpf=dict(...), view='active'|'fim_mean'|'random'|'maxrot'|'fixed', stop=True)"""
    nom = nom or Nominal()
    plant = copy.deepcopy(plant)
    plant.nom = nom
    rng_est = np.random.default_rng(trial["seed"] * 31 + 17 + seed_offset)
    plant.rng = np.random.default_rng(trial["seed"] * 31 + 5)    # same plant noise for all variants
    t_wall = time.time()
    theta = cal["theta"]
    cpf = CPF(B_LO, B_HI, rng_est, **variant.get("cpf", {}))
    plant.set_contact(trial["p"], trial["fW"], ripple=trial.get("ripple", 0.02), wobble_deg=trial.get("wobble_deg", 1.0))
    t_on = plant.t
    plant.run(1.0)
    q_cur = plant.q_hold.copy()
    o_fix = cal["o_home"]
    log = []
    t_sel = []
    n_views = 0
    for k in range(MAX_VIEWS):
        Rw, Qw = window(plant, T_WIN)
        R, _, J = nom.kin(Qw.mean(0))
        Y = payload_regressor(R, J)
        cpf.start_view(R, J, cal["sig_sub2"], cal["sig_mod2"])
        for i in range(len(Rw)):
            cpf.update(Rw[i] - Y @ theta)
        fE_true = R.T @ trial["fW"]
        e_true = Rw.mean(0) - Y @ theta - J.T @ np.concatenate([fE_true, np.cross(trial["p"], fE_true)])
        n_views += 1
        bat = {}
        if variant.get("batch"):
            from .estimator import batch_estimate
            vW = [(v.A, v.R, v.stats()[3]) for v in cpf.views if v.n > 0]
            pb, Cb, rb = batch_estimate(cpf.stats_list(), vW, cpf.sig_df(), B_LO, B_HI, np.random.default_rng(trial["seed"] + 99))
            eb = pb - trial["p"]
            bat = dict(batch_err=float(np.linalg.norm(eb)), batch_r95=rb,
                       batch_nees=float(eb @ np.linalg.solve(Cb, eb)))
        geo = {}
        if k == 0:
            m0, C0, _ = cpf.moments()
            lam, V = np.linalg.eigh(C0)
            u_t = R.T @ trial["fW"]; u_t /= np.linalg.norm(u_t)
            d = m0 - trial["p"]
            geo = dict(axis_angle=float(np.degrees(np.arccos(min(1.0, abs(V[:, -1] @ u_t))))),
                       axis_ratio=float(np.sqrt(lam[-1] / max(lam[-2], 1e-12))),
                       perp_err=float(np.linalg.norm(d - (d @ u_t) * u_t)))
        s_along = along_line_std(cpf, cal)
        if snapshots is not None:
            snapshots.append(dict(stage=f"view{k+1}", P=cpf.P.copy(), w=cpf.w(), R=R.copy()))
        fired = cpf.end_view(info_std_along=s_along)
        if snapshots is not None and fired:
            snapshots.append(dict(stage=f"view{k+1}_D3", P=cpf.P.copy(), w=cpf.w(), R=R.copy()))
        m, C, r95, f = cpf.summary()
        e_k = m - trial["p"]
        try:
            nees_k = float(e_k @ np.linalg.solve(C + 1e-12 * np.eye(3), e_k))
        except np.linalg.LinAlgError:
            nees_k = float("inf")
        log.append(dict(view=k + 1, p=m.tolist(), r95=float(r95), err=float(np.linalg.norm(e_k)), nees=nees_k,
                        s_along=s_along, D3=bool(fired), t=plant.t - t_on,
                        e_true=e_true.tolist(), **geo, **bat, sig_assumed=np.sqrt(cpf.views[-1].var(cpf.views[-1].rsum / cpf.views[-1].n)).tolist()))
        if variant.get("stop", True) and n_views >= MIN_VIEWS and r95 < R95_STOP and not fired:
            break
        if k == MAX_VIEWS - 1:
            break
        # ---- next view
        ts = time.time()
        vmode = variant.get("view", "active")
        R_cur, _, _ = nom.kin(q_cur)
        if vmode == "fixed":
            if k >= len(fixed_views):
                break
            ax, ang = fixed_views[k]
            Rt = rotvec_to_R(ang * ax) @ R_cur
            qt, err = nom.ik(q_cur, Rt, o_fix, q_rest=q_cur)
            nxt = dict(q=qt, R=Rt, ang=ang) if err < 2e-3 else None
        else:
            visited = [v.R for v in cpf.views]
            cands = [c for c in candidates(nom, q_cur, R_cur, cal["R_home"], o_fix, visited)
                     if feasible(nom, c, theta, f, m)]
            if not cands:
                nxt = None
            elif vmode == "random":
                nxt = cands[rng_est.integers(len(cands))]
            elif vmode == "maxrot":
                nxt = max(cands, key=lambda c: c["ang"])
            else:
                sc = score_candidates(nom, cpf, cands, cal, vmode, rng_est)
                nxt = cands[int(np.argmax(sc))]
        t_sel.append(time.time() - ts)
        if nxt is None:
            break
        qs = orient_waypoints(nom, q_cur, nxt["R"], o_fix)
        if qs is None:
            break
        move_and_settle(plant, qs, T_MOVE, T_SET)
        q_cur = plant.q_hold.copy()
    m, C, r95, f = cpf.summary()
    e = m - trial["p"]
    err = float(np.linalg.norm(e))
    try:
        nees = float(e @ np.linalg.solve(C + 1e-12 * np.eye(3), e))
    except np.linalg.LinAlgError:
        nees = np.inf
    fW = trial["fW"]
    res = dict(
        seed=trial["seed"], err=err, r95=float(r95), cbw=bool(r95 < R_CONF and err > E_TOL),
        covered=bool(nees <= chi2.ppf(0.95, 3)), nees=nees,
        f_mag_err=float(abs(np.linalg.norm(f) - np.linalg.norm(fW)) / np.linalg.norm(fW)),
        f_ang_err=float(np.degrees(np.arccos(np.clip(f @ fW / (np.linalg.norm(f) * np.linalg.norm(fW) + 1e-12), -1, 1)))),
        f_true=float(np.linalg.norm(fW)), payload=float(trial["obj"]["mass"]),
        views=n_views, t_loc=float(plant.t - t_on), counts=cpf.counts, log=log,
        t_sel=float(np.mean(t_sel)) if t_sel else 0.0, wall=time.time() - t_wall, c_stat=cal["c_stat"],
    )
    return res

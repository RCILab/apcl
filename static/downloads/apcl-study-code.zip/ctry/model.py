"""MJCF construction for the FR3 plant (true) and the estimator's nominal model.

Inertial parameters of links 1-7 follow MuJoCo Menagerie `franka_fr3/fr3.xml`.
The plant differs from the nominal model by link mass / CoM errors, joint damping
error, residual dry friction, optional joint springs, and it carries the grasped
object (the unknown payload). Geometry is irrelevant (collisions are disabled).
"""
import numpy as np
import mujoco

# name, parent-relative pos, quat, inertial pos, inertial quat, mass, diaginertia, range, torque limit
LINKS = [
    ("link1", (0, 0, 0.333), (1, 0, 0, 0), (4.128e-07, -0.0181251, -0.0386036),
     (0.998098, -0.0605364, 0.00380499, 0.0110109), 2.92747, (0.0239286, 0.0227246, 0.00610634), (-2.7437, 2.7437), 87),
    ("link2", (0, 0, 0), (1, -1, 0, 0), (0.00318289, -0.0743222, 0.00881461),
     (0.502599, 0.584437, -0.465998, 0.434366), 2.93554, (0.0629567, 0.0411924, 0.0246371), (-1.7837, 1.7837), 87),
    ("link3", (0, -0.316, 0), (1, 1, 0, 0), (0.0407016, -0.00482006, -0.0289731),
     (0.921025, -0.244161, 0.155272, 0.260745), 2.2449, (0.0267409, 0.0189869, 0.0171587), (-2.9007, 2.9007), 87),
    ("link4", (0.0825, 0, 0), (1, 1, 0, 0), (-0.0459101, 0.0630493, -0.00851879),
     (0.438018, 0.803311, 0.00937812, 0.403414), 2.6156, (0.05139, 0.0372717, 0.0160047), (-3.0421, -0.1518), 87),
    ("link5", (-0.0825, 0.384, 0), (1, -1, 0, 0), (-0.00160396, 0.0292536, -0.0972966),
     (0.919031, 0.125604, 0.0751531, -0.366003), 2.32712, (0.0579335, 0.0449144, 0.0130634), (-2.8065, 2.8065), 12),
    ("link6", (0, 0, 0), (1, 1, 0, 0), (0.0597131, -0.0410295, -0.0101693),
     (0.621301, 0.552665, 0.510011, 0.220081), 1.81704, (0.0175039, 0.0161123, 0.00193529), (0.5445, 4.5169), 12),
    ("link7", (0.088, 0, 0), (1, 1, 0, 0), (0.00452258, 0.00862619, -0.0161633),
     (0.727579, 0.0978688, -0.24906, 0.63168), 0.627143, (0.000223836, 0.000223642, 5.64132e-07), (-3.0159, 3.0159), 12),
]
ARMATURE = np.array([0.195, 0.195, 0.195, 0.195, 0.074, 0.074, 0.074])
DAMPING = np.array([0.21] * 7)
TAU_MAX = np.array([l[8] for l in LINKS], dtype=float)
Q_LO = np.array([l[7][0] for l in LINKS])
Q_HI = np.array([l[7][1] for l in LINKS])
Q_READY = np.array([0.0, -np.pi / 4, 0.0, -3 * np.pi / 4, 0.0, np.pi / 2, np.pi / 4])

# Franka hand (known, part of the nominal robot) and TCP offset from the flange.
FLANGE_Z = 0.107
HAND_MASS = 0.73
HAND_COM = (-0.01, 0.0, 0.03)
HAND_INERTIA = (0.001, 0.0025, 0.0017)
TCP_Z = 0.1034


def _f(v):
    return " ".join(f"{x:.9g}" for x in v)


def build_xml(link_mass_scale=None, link_com_offset=None, damping=None, frictionloss=None,
              stiffness=None, springref=None, obj=None, dt=0.001):
    """Return an MJCF string. `obj` = dict(mass, com (3,), inertia (3,)) in the TCP frame, or None."""
    n = len(LINKS)
    ms = np.ones(n) if link_mass_scale is None else np.asarray(link_mass_scale)
    co = np.zeros((n, 3)) if link_com_offset is None else np.asarray(link_com_offset)
    dmp = DAMPING if damping is None else np.asarray(damping)
    fl = np.zeros(n) if frictionloss is None else np.asarray(frictionloss)
    st = np.zeros(n) if stiffness is None else np.asarray(stiffness)
    sr = np.zeros(n) if springref is None else np.asarray(springref)

    body_open, body_close = [], []
    for i, (name, pos, quat, ipos, iquat, mass, dinert, rng, _) in enumerate(LINKS):
        m = mass * ms[i]
        body_open.append(
            f'<body name="{name}" pos="{_f(pos)}" quat="{_f(quat)}">'
            f'<inertial pos="{_f(np.array(ipos) + co[i])}" quat="{_f(iquat)}" mass="{m:.9g}" '
            f'diaginertia="{_f(np.array(dinert) * ms[i])}"/>'
            f'<joint name="j{i+1}" axis="0 0 1" range="{rng[0]} {rng[1]}" armature="{ARMATURE[i]}" '
            f'damping="{dmp[i]:.6g}" frictionloss="{fl[i]:.6g}" stiffness="{st[i]:.6g}" springref="{sr[i]:.6g}"/>')
        body_close.append("</body>")
    hand = (f'<body name="hand" pos="0 0 {FLANGE_Z}">'
            f'<inertial pos="{_f(HAND_COM)}" mass="{HAND_MASS}" diaginertia="{_f(HAND_INERTIA)}"/>'
            f'<site name="tcp" pos="0 0 {TCP_Z}"/>')
    if obj is not None:
        hand += (f'<body name="object" pos="0 0 {TCP_Z}">'
                 f'<inertial pos="{_f(obj["com"])}" mass="{obj["mass"]:.9g}" diaginertia="{_f(obj["inertia"])}"/>'
                 f'</body>')
    hand += "</body>"
    chain = "".join(body_open) + hand + "".join(reversed(body_close))
    acts = "".join(f'<motor joint="j{i+1}" ctrlrange="{-TAU_MAX[i]} {TAU_MAX[i]}" ctrllimited="true"/>'
                   for i in range(n))
    return f"""<mujoco model="fr3">
  <compiler angle="radian" autolimits="true"/>
  <option timestep="{dt}" integrator="implicitfast" gravity="0 0 -9.81">
    <flag contact="disable"/>
  </option>
  <worldbody>{chain}</worldbody>
  <actuator>{acts}</actuator>
</mujoco>"""


def nominal_model(dt=0.001):
    return mujoco.MjModel.from_xml_string(build_xml(dt=dt))


def box_object(dims, offset, mass):
    """Solid box in the TCP frame: dims=(lx,ly,lz) full lengths, box spans z in [offset_z, offset_z+lz]."""
    lx, ly, lz = dims
    com = np.array([offset[0], offset[1], offset[2] + lz / 2])
    inertia = mass / 12 * np.array([ly**2 + lz**2, lx**2 + lz**2, lx**2 + ly**2])
    return dict(mass=mass, com=com, inertia=inertia, dims=np.array(dims), offset=np.array(offset))

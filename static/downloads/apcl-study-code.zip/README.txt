APCL study code snapshot

Python 3.12; numpy, scipy and mujoco are required.
Entry point: python run_experiments.py --help
This snapshot is provided for inspection and reproduction of the simulation study.
The project is in progress; hardware validation is not included.
See episode.json in the data archive for hashes of the captured implementation.
